Flat files
by Kev Simpson
http://kev-simpson.me and twitter.com/kevsimps


These are for you to have and to hold and to do with however you like under the Creative Commons Attribution 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by/3.0/


Attribution isn't necessary but please don't make out that you made them and/or sell them.
Otherwise feel free to use these icons as you please. Oh and I'd love to see them in use so please do drop me a link :)